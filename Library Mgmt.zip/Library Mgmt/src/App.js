import logo from './logo.svg';
import './App.css';
import HomePage from './Components/home.js';

function App() {
  return (
    <>
        <HomePage/>
    </>

  );
}

export default App;
