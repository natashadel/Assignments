import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Routes, Route, Link, Outlet, BrowserRouter as Router } from 'react-router-dom';

import HomePage from './Components/home';
import AboutUs from './Components/about';
import ContactPage from './Components/contact';
import SignIn from './Components/signin';
import SignUp from './Components/signup';
import Books from './Components/books';
import Footer from './Components/footer';
import NotFound from './Components/notfound';


const routing = (
  <Router>
    <div className="header" style={{ backgroundColor: "lightsalmon", paddingBottom: "20px" }}>
      <img src='library.png' style={{ marginLeft: "20px", position: "relative" }} width="80px" height={"80px"}></img>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <span style={{ color: "white", fontSize: "60px", textAlign: "center", marginLeft: "110px" }}>Library Management System</span>
    </div>

    <br /><br />

    <div className='bodyContainer' style={{ textAlign: "center" }}>
      <div className="btn-group">
        <Link to="/"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>Home</button></Link>
        <Link to="/AboutUs"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>About</button></Link>
        <Link to="/ContactPage"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>Contact</button></Link>
        <Link to="/SignIn"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>Login</button></Link>
        <Link to="/SignUp"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>Registration</button></Link>
        <Link to="/Books"><button type="button" className="mx-1 btn btn-primary" style={{ fontSize: "20px" }}>Books</button></Link>
      </div>
    </div>
    <hr />
    <Routes>
      <Route path="/" element={<App/>} />
      <Route path="/AboutUs" element={<AboutUs/>} />
      <Route path="/ContactPage" element={<ContactPage/>} />
      <Route path="/SignIn" element={<SignIn/>} />
      <Route path="/SignUp" element={<SignUp/>} />
      <Route path="/Books" element={<Books/>} />
      <Route path="*" element={<NotFound/>} />

    </Routes>

    <Footer/>

  </Router>)

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
