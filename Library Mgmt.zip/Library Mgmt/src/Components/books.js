import React from "react";
import { useState, useEffect } from "react";
import dataServiceObj from "../dataService";

function Books() {

    const [listOfBooks, setBookList] = useState([]);

    const [title, setTitle] = useState("");
    const [img, setImg] = useState("");

    const [selBookInd, setSelBookInd] = useState(-1);
    


    function getBooks_click() {

        dataServiceObj.getData().then(resData => {
            setBookList(resData.data);
        });
    }

    function addBook_click() {

        let bookObj = {};

        bookObj.title = title;
        bookObj.img = img;


        dataServiceObj.addData(bookObj).then(resData => {
            alert("New Book details are added to Server");
            getBooks_click();
            setTitle("");
            setImg("");
        });

    }


    function deleteBook_click(bid) {

        dataServiceObj.deleteData(bid).then(resData => {
            alert("Book details are deleted from Server");
            getBooks_click();
        });
    }

    function selectBook_click(bid) {

        setSelBookInd(listOfBooks.findIndex(item => item.bid == bid));

        dataServiceObj.getDataById(bid).then(resData => {

            let bookObj = resData.data;
            setTitle(bookObj.title);
            setImg(bookObj.img);
        });
    }

    function updateBook_click() {

        if (selBookInd == -1) {
            alert("First select a book");
            return;
        }

        let bookObj = {};

        bookObj.bid = listOfBooks[selBookInd].bid;
        bookObj.title = title;
        bookObj.img = img;

        dataServiceObj.updateData(bookObj).then((resData) => {
            alert("Book details are updated in  Server");
            getBooks_click();
        });

        setTitle("");
        setImg("");

        setSelBookInd(-1);

    }

    let result = "";

    
        result = listOfBooks.map(item =>

            <div className="card m-3 book" style={{ width: "18rem", maxWidth: "18%", flex: "18%" }}>
                <img className="card-img-top" src={item.img} height={"150px"} alt="Card image cap" />
                <div className="card-body" style={{ textAlign: "center" }}>
                    <h5 className="card-title">{item.title}</h5>
                    <a href="javascript:void(0)" className="btn btn-primary" onClick={() => selectBook_click(item.bid)}>Select</a>&nbsp;&nbsp;
                    <a href="javascript:void(0)" className="btn btn-primary" onClick={() => deleteBook_click(item.bid)}>Delete</a>
                </div>
            </div>)

    return (

        <div className="m-2">

            <h3 style={{ textAlign: "center" }}>Dynamic Operations (CRUD) on List of Books</h3>

            <h4>Enter Book Details</h4><br />

            <h5 style={{ display: "inline" }}>Title : &nbsp;&nbsp;</h5><input value={title} onChange={e => setTitle(e.target.value)} /><br /><br />
            <h5 style={{ display: "inline" }}>Image Link : &nbsp;&nbsp;</h5><input value={img} onChange={e => setImg(e.target.value)} />
            <br /><br />

            <input type="button" value="Get Books" onClick={getBooks_click} />
            <input type="button" value="Add Book" onClick={addBook_click} />
            <input type="button" value="Update Book" onClick={updateBook_click} />
            <br /><br />

            <div id="booksList" style={{ display: "flex", flexWrap: "wrap", alignContent: "center" }}>
                {result}
            </div>
        </div>
    )
}

export default Books;