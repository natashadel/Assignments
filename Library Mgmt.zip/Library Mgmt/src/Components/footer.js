import React from "react";
import "../cssFiles/footer.css"

function Footer() {
    return (
        <div id="section5" className="row mt-5 ps-5 pt-4">
            <div className="col" style={{ padding: "0px", marginRight: "35px" }}>
                <h5 className="mb-5" style={{ color: "darkred", fontWeight: "bold" }}>Categories</h5>
                <p><a href="#">Aenean nonum hendreri</a></p>
                <p><a href="#">Cum sociis natoque pen</a></p>
                <p><a href="#">Fusce suscipit varius</a></p>
                <p><a href="#">Magnis dis parturient</a></p>
                <p><a href="#">Nascetur ridiculus mus</a></p>
            </div>
            <div className="col" style={{ padding: "0px", marginRight: "35px" }}>
                <h5 className="mb-5" style={{ color: "darkred", fontWeight: "bold" }}>Follow us</h5>
                <p><a href="#">Twitter</a></p>
                <p><a href="#">Facebook</a></p>
                <p><a href="#">Google Plus</a></p>
                <p><a href="#">Flickr</a></p>
            </div>
            <div className="col" style={{ padding: "0px", marginRight: "35px" }}>
                <h5 className="mb-5" style={{ color: "darkred", fontWeight: "bold" }}>Archive</h5>
                <p><a href="#">August 2012</a></p>
                <p><a href="#">July 2012</a></p>
                <p><a href="#">June 2012</a></p>
                <p><a href="#">May 2012</a></p>
                <p><a href="#">April 2012</a></p>
            </div>
            <div className="col" style={{ padding: "0px" }}>
                <h5 className="mb-5" style={{ color: "darkred", fontWeight: "bold" }}>Copyright</h5>
                <p><a href="#">Library&copy;2015 Privacy Policy</a></p>
            </div>
        </div>
    )
}

export default Footer;