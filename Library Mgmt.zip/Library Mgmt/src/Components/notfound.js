import React from "react";

function NotFound()
{
    return(
        <>
        </>
    )
}

export default NotFound;