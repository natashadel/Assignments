import React from "react";

function ContactPage() {
    return (
        <div id="body2" className="mt-5 mb-4" style={{ width: "70%", margin: "auto"}}>
            <div id="section1" className="row border" style={{ boxShadow: "5px 5px 5px gray" }}>
                <div className="col-4" style={{ backgroundColor: "white" }}>
                    <div className="row mt-3" style={{ textAlign: "center" }}>
                        <h4 style={{ color: "darksalmon", fontWeight: "bold" }}>CONTACT US</h4>
                    </div>
                    <br />

                    <div className="row mt-3" style={{ color: "gray" }}>
                        <span style={{ fontSize: "15px", padding: "8px", margin: "6px" }}>
                            <i className="bi bi-geo-alt-fill"></i>
                            &nbsp;72-1 Jigatola, Dhanmondi Dhaka, BD
                        </span>
                        <span style={{ fontSize: "15px", padding: "8px", margin: "6px" }}>
                            <i className="bi bi-envelope"></i>
                            &nbsp;contactus@abclibrary.com
                        </span>
                        <span style={{ fontSize: "15px", padding: "8px", margin: "6px" }}>
                            <i className="bi bi-telephone-fill"></i>
                            &nbsp;0651-8486888468
                        </span>
                        <span style={{ fontSize: "15px", padding: "8px", margin: "6px" }}>
                            <i className="bi bi-three-dots-vertical"></i>
                            &nbsp;To know more connect me.
                        </span>
                    </div>

                </div>
                <div className="col-8" style={{ backgroundColor: "darksalmon" }}>
                    <div className="text-primary">
                        <form action="server_page.php" className="was-validated">

                            <div className="mb-3 mt-3">
                                <div className="input-group mb-3">
                                    <span className="input-group-text"><i className="bi bi-person-fill"></i></span>
                                    <input type="email" className="form-control" placeholder="Enter your email" required />
                                    <div className="valid-feedback">Valid.</div>
                                    <div className="invalid-feedback">Please fill out this field.</div>
                                </div>
                            </div>

                            <div className="mb-3 mt-3">
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control" placeholder="Subject" required />
                                    <span className="input-group-text"><i className="bi bi-key-fill"></i></span>
                                </div>
                            </div>

                            <div className="mb-3 mt-3">
                                <div className="input-group mb-3">
                                    <textarea className="form-control" placeholder="Enter your text here....." required></textarea>
                                    <span className="input-group-text"><i className="bi bi-key-fill"></i></span>
                                </div> 
                            </div>

                            <button type="submit" className="btn btn-secondary mt-5" style={{ display: "block", width: "100%" }}>Send</button>
                            <br/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ContactPage;