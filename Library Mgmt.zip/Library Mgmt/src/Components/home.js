import React from "react";
import "../cssFiles/home.css"


function HomePage() {
    return (
        <div id="container" className="containers">
            <div className="carousel slide mx-4" data-interval="1000" data-bs-ride="carousel" style={{ position: "relative", top: "45%" }}>
                <div className="carousel-inner" style={{ color: "white", textAlign: "center" }}>
                    <div className="carousel-item active">
                        <h2>"A library outranks any other one thing a community can do to benefit its people. It is a never-failing spring in the desert.” ~ Andrew Carnegie</h2>
                    </div>
                    <div className="carousel-item">
                        <h2>“A library is the delivery room for the birth of ideas, a place where history comes to life.” ~ Norman Cousins</h2>
                    </div>
                    <div className="carousel-item">
                        <h2>“The only thing that you absolutely have to know, is the location of the library.” ~ Albert Einstein</h2>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HomePage;