import axios from 'axios';

let dataServiceObj = {};

let url = "http://localhost:3500/books/";

dataServiceObj.getData = function()
{
    return axios.get(url);
};

dataServiceObj.getDataById = function( bid )
{
    return axios.get(url + bid);
};

dataServiceObj.addData = function( bookObj )
{
    return axios.post(url, bookObj);
};

dataServiceObj.updateData = function( bookObj )
{
    return axios.put(url + bookObj.bid,  bookObj);
};

dataServiceObj.deleteData = function( bid )
{
    return axios.delete(url + bid);
};

export default dataServiceObj;